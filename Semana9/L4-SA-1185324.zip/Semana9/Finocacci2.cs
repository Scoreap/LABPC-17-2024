﻿using System;

namespace Semana9
{
   class  Fibonacci2
   {
        static void Main(string[]args)
        {
            int n;
            string resultado = " ";
            int a = 0;
            int b = 1;
            int c = 0;
            int i = 2;

            Console.WriteLine("Ingrese un neumero que sea mayor a cero: ");
                n = Int32.Parse(Console.ReadLine());

            if (n > 0)
            {   
                resultado += a;

                if (n > 1)
                {
                    resultado += "-" + b;
                }
                while (n > i)
                {
                    c = a + b;
                    resultado += "-" + c;
                    a = b;
                    b = c;
                    i = i + 1;
                }
            Console.WriteLine(resultado );
    
            }
            Console.ReadKey();
           
        }
    }
}

